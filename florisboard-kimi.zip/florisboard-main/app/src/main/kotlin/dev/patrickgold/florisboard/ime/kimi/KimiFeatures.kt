/*
 * Copyright (C) 2026 The FlorisBoard Contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package dev.patrickgold.florisboard.ime.kimi

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Shared state + pure text helpers for the Kimi-style extras:
 *  - dotted numbers   (1 3 4  ->  1.3.4.)
 *  - reversed typing  (123 -> 321, كاس -> ساك)
 *  - auto clicker     (repeats the last typed text / enter at a fixed interval)
 */
object KimiFeatures {
    private val _dottedNumbers = MutableStateFlow(false)
    val dottedNumbers: StateFlow<Boolean> = _dottedNumbers

    private val _reverseText = MutableStateFlow(false)
    val reverseText: StateFlow<Boolean> = _reverseText

    private val _autoClicker = MutableStateFlow(false)
    val autoClicker: StateFlow<Boolean> = _autoClicker

    val autoClickIntervalsMs = longArrayOf(100L, 300L, 600L, 1000L, 2000L)
    private val _autoClickIntervalIndex = MutableStateFlow(1)
    val autoClickIntervalIndex: StateFlow<Int> = _autoClickIntervalIndex
    val autoClickIntervalMs: Long get() = autoClickIntervalsMs[_autoClickIntervalIndex.value]

    /** Length (in chars) of the reversed run currently being typed. */
    var reverseRunLength: Int = 0

    fun toggleDottedNumbers() { _dottedNumbers.value = !_dottedNumbers.value }

    fun toggleReverseText() {
        _reverseText.value = !_reverseText.value
        reverseRunLength = 0
    }

    fun setAutoClicker(enabled: Boolean) { _autoClicker.value = enabled }

    fun cycleAutoClickInterval() {
        _autoClickIntervalIndex.value = (_autoClickIntervalIndex.value + 1) % autoClickIntervalsMs.size
    }

    private val _spelling = MutableStateFlow(false)
    val spelling: StateFlow<Boolean> = _spelling
    fun toggleSpelling() { _spelling.value = !_spelling.value }

    private val _shortcuts = MutableStateFlow(true)
    val shortcutsEnabled: StateFlow<Boolean> = _shortcuts
    fun toggleShortcuts() { _shortcuts.value = !_shortcuts.value }

    /** Default shortcuts from Kimi keyboard: type the trigger then space to expand it. */
    val shortcuts: MutableMap<String, String> = linkedMapOf(
        "سلام" to "السلام عليكم ورحمة الله وبركاته",
        "وعليكم" to "وعليكم السلام ورحمة الله وبركاته",
        "مع السلامة" to "مع السلامة، إلى اللقاء 👋",
        "شكرا" to "شكراً جزيلاً 🌹",
        "عافاك" to "بارك الله فيك 🙏",
        "ان شاء الله" to "إن شاء الله 🤲",
        "صباح الخير" to "صباح الخير 🌅",
        "مساء الخير" to "مساء الخير 🌙",
    )

    /** Returns (trigger, expansion) if the text before the cursor ends with a known trigger. */
    fun matchShortcut(before: String): Pair<String, String>? {
        var best: Pair<String, String>? = null
        for ((t, e) in shortcuts) {
            if (!before.endsWith(t)) continue
            val i = before.length - t.length
            if (i != 0 && !before[i - 1].isWhitespace()) continue
            if (best == null || t.length > best.first.length) best = t to e
        }
        return best
    }

    private val digitRegex = Regex("(\\p{Nd})")

    /** 1 3 4 -> "1.3.4."  (every digit gets a dot after it) */
    fun dotDigits(text: String): String = digitRegex.replace(text, "$1.")

    /** Reverse the letters of every word, keeping spaces/newlines in place: "كاس ab" -> "ساك ba". */
    fun reverseWords(text: String): String {
        val sb = StringBuilder()
        val word = StringBuilder()
        fun flush() {
            if (word.isNotEmpty()) {
                // reverse by code points so emoji / surrogate pairs are not broken
                val cps = word.toString().codePoints().toArray()
                for (i in cps.indices.reversed()) sb.appendCodePoint(cps[i])
                word.setLength(0)
            }
        }
        for (ch in text) {
            if (ch.isWhitespace()) { flush(); sb.append(ch) } else word.append(ch)
        }
        flush()
        return sb.toString()
    }

    /** A "unit" typed by a single key press: not whitespace, not multi-word. */
    fun isSingleTypedUnit(text: String): Boolean {
        if (text.isEmpty()) return false
        if (text.any { it.isWhitespace() }) return false
        // single key press (one code point, optionally + the dot we appended after a digit)
        val cps = text.codePointCount(0, text.length)
        return cps == 1 || (cps == 2 && text.endsWith(".") && text.first().isDigit())
    }

    fun isWordUnit(text: String): Boolean {
        val first = text.codePointAt(0)
        return Character.isLetterOrDigit(first)
    }
}
