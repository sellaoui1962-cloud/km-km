/*
 * Copyright (C) 2026 The FlorisBoard Contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package dev.patrickgold.florisboard.ime.kimi

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import java.lang.ref.WeakReference

/**
 * Real screen auto clicker. It shows a draggable target (crosshair) and a small control bar
 * (play/pause, close) above every app. While running it taps the target's centre on the screen
 * every [KimiFeatures.autoClickIntervalMs] using the accessibility gesture API.
 *
 * Android only allows this through an enabled accessibility service, so the user has to switch
 * "Floris Auto Clicker" on once in Settings > Accessibility.
 */
class AutoClickService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var target: TextView? = null
    private var targetParams: WindowManager.LayoutParams? = null
    private var bar: LinearLayout? = null
    private var barParams: WindowManager.LayoutParams? = null
    private var playBtn: TextView? = null
    private var running = false

    private val density get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = WeakReference(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopClicking() }

    override fun onDestroy() {
        stopClicking()
        removeOverlays()
        KimiFeatures.setAutoClicker(false)
        instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- public API

    /** Show the target + control bar so the user can position the target and press play. */
    fun showControls() {
        if (target != null) return
        addTarget()
        addBar()
        KimiFeatures.setAutoClicker(true)
    }

    fun hideControls() {
        stopClicking()
        removeOverlays()
        KimiFeatures.setAutoClicker(false)
    }

    // ---------------------------------------------------------------- clicking

    private val clickRunnable = object : Runnable {
        override fun run() {
            if (!running) return
            val t = target ?: return
            val loc = IntArray(2)
            t.getLocationOnScreen(loc)
            val x = loc[0] + t.width / 2f
            val y = loc[1] + t.height / 2f
            val path = Path().apply { moveTo(x, y) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, 40L))
                .build()
            val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { scheduleNext() }
                override fun onCancelled(g: GestureDescription?) { scheduleNext() }
            }, null)
            if (!dispatched) scheduleNext()
        }
    }

    private fun scheduleNext() {
        if (running) handler.postDelayed(clickRunnable, KimiFeatures.autoClickIntervalMs)
    }

    private fun startClicking() {
        if (running) return
        running = true
        setTargetTouchable(false) // taps must pass through the marker to the app below
        playBtn?.text = "⏸"
        handler.postDelayed(clickRunnable, 300L)
    }

    private fun stopClicking() {
        running = false
        handler.removeCallbacks(clickRunnable)
        setTargetTouchable(true)
        playBtn?.text = "▶"
    }

    // ---------------------------------------------------------------- overlays

    private fun overlayParams(w: Int, h: Int, touchable: Boolean) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT,
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun addTarget() {
        val size = dp(56)
        val tv = TextView(this).apply {
            text = "✛"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(150, 220, 40, 40))
                setStroke(dp(2), Color.WHITE)
            }
        }
        val lp = overlayParams(size, size, true).apply {
            x = resources.displayMetrics.widthPixels / 2 - size / 2
            y = resources.displayMetrics.heightPixels / 3
        }
        attachDrag(tv, lp, onClick = null)
        wm.addView(tv, lp)
        target = tv
        targetParams = lp
    }

    private fun setTargetTouchable(touchable: Boolean) {
        val t = target ?: return
        val lp = targetParams ?: return
        lp.flags = if (touchable) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        runCatching { wm.updateViewLayout(t, lp) }
    }

    private fun barButton(label: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 20f
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(color) }
        setOnClickListener { onClick() }
    }

    private fun addBar() {
        val handle = TextView(this).apply {
            text = "⠿"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(8), 0)
        }
        val play = barButton("▶", Color.rgb(46, 160, 67)) {
            if (running) stopClicking() else startClicking()
        }
        playBtn = play
        val close = barButton("✕", Color.rgb(200, 50, 50)) { hideControls() }
        val speed = barButton("⏱", Color.rgb(60, 90, 200)) { KimiFeatures.cycleAutoClickInterval() }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.argb(210, 30, 30, 30))
            }
            addView(handle)
            addView(play)
            addView(View(context).apply { layoutParams = LinearLayout.LayoutParams(dp(6), 1) })
            addView(speed)
            addView(View(context).apply { layoutParams = LinearLayout.LayoutParams(dp(6), 1) })
            addView(close)
        }
        val lp = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, true)
            .apply {
                x = dp(12)
                y = resources.displayMetrics.heightPixels / 5
            }
        attachDrag(handle, lp, onClick = null, dragged = row)
        wm.addView(row, lp)
        bar = row
        barParams = lp
    }

    /** Drag [touchView] to move [dragged] (defaults to [touchView] itself). */
    private fun attachDrag(
        touchView: View,
        lp: WindowManager.LayoutParams,
        onClick: (() -> Unit)?,
        dragged: View = touchView,
    ) {
        var startX = 0; var startY = 0; var downX = 0f; var downY = 0f; var moved = false
        touchView.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y; downX = ev.rawX; downY = ev.rawY; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - downX).toInt(); val dy = (ev.rawY - downY).toInt()
                    if (Math.abs(dx) > 6 || Math.abs(dy) > 6) moved = true
                    lp.x = startX + dx; lp.y = startY + dy
                    runCatching { wm.updateViewLayout(dragged, lp) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) onClick?.invoke(); true }
                else -> false
            }
        }
    }

    private fun removeOverlays() {
        target?.let { runCatching { wm.removeView(it) } }
        bar?.let { runCatching { wm.removeView(it) } }
        target = null; bar = null; targetParams = null; barParams = null; playBtn = null
    }

    companion object {
        @Volatile
        private var instance: WeakReference<AutoClickService>? = null

        fun get(): AutoClickService? = instance?.get()
        val isEnabled: Boolean get() = get() != null
    }
}
