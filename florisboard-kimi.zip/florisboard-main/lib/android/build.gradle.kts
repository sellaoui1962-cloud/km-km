import com.android.build.api.dsl.LibraryExtension
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

/*
 * Copyright (C) 2026 The FlorisBoard Contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

plugins {
    alias(libs.plugins.agp.library)
    alias(libs.plugins.kotlin.serialization)
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_11)
        freeCompilerArgs.set(listOf(
            "-opt-in=kotlin.contracts.ExperimentalContracts",
            "-Xwhen-guards",
        ))
    }
}

configure<LibraryExtension> {
    namespace = "org.florisboard.lib.android"
    compileSdk = providers.gradleProperty("projectCompileSdk").get().toInt()

    defaultConfig {
        minSdk = providers.gradleProperty("projectMinSdk").get().toInt()

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        consumerProguardFiles("consumer-rules.pro")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        create("beta") {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    // FIXME: This is a workaround! Otherwise :lib:snygg:generateJsonSchema breakes.
    //  Remove the lint block when we've migrated to the newDsl.
    lint {
        disable.addAll(
            listOf(
                "UElementAsPsi",
                "ApplySharedPref",
                "CommitTransaction",
                "Recycle",
                "CommitPrefEdits",
            )
        )
    }
}

dependencies {
    implementation(projects.lib.kotlin)
    implementation(libs.androidx.core.ktx)
    implementation(libs.kotlinx.serialization.json)
}
