/*
 * Copyright (C) 2025 The FlorisBoard Contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.florisboard.lib.snygg.color

import androidx.compose.runtime.saveable.Saver
import com.materialkolor.Contrast
import com.materialkolor.PaletteStyle
import com.materialkolor.dynamiccolor.ColorSpec
import kotlinx.serialization.EncodeDefault
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@OptIn(ExperimentalSerializationApi::class)
@Serializable
data class MaterialYouFlags(
    @EncodeDefault
    val paletteStyle: PaletteStyle = PaletteStyle.Neutral,
    @EncodeDefault
    val contrastLevel: Contrast = Contrast.Default,
    @EncodeDefault
    val specVersion: ColorSpec.SpecVersion = ColorSpec.SpecVersion.Default,
)

val MaterialYouFlagsSaver = Saver<MaterialYouFlags, String>(
    save = { Json.encodeToString(it) },
    restore = { Json.decodeFromString(it) }
)
